/**********************************************************************
Copyright (c) 2008 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
    ...
**********************************************************************/
package org.jpox.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jdo.Extent;
import javax.jdo.JDOHelper;
import javax.jdo.datastore.JDOConnection;
import javax.jdo.JDOOptimisticVerificationException;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Query;
import javax.jdo.Transaction;

import com.db4o.query.Predicate;

import org.jpox.jdo.JPOXJDOHelper;
import org.jpox.util.JPOXLogger;

/**
 * Sample JPOX-DB4O Application.
 * Prepared for ICOODB 2008.
 */
public class Main
{
    static PersistenceManagerFactory pmf = null;

    static public void main(String[] args)
    {
        // Create a PMF for our "persistence-unit"
        // Refer to the file "META-INF/persistence.xml"
        pmf = JDOHelper.getPersistenceManagerFactory("myUnit");

        // Persist a Person object and detach it
        PersistenceManager pm = pmf.getPersistenceManager();
        pm.setDetachAllOnCommit(true);
        pm.setCopyOnAttach(false);
        Transaction tx = pm.currentTransaction();

        Person p1 = new Person("John", "Smith"); // p1 now "transient"
        try
        {
            tx.begin();
            pm.makePersistent(p1); // p1 now "persistent"
            tx.commit(); // p1 now "detached"
        }
        finally
        {
            if (tx.isActive()) { tx.rollback(); }
        }

        // Update the detached Person object and attach it
        p1.setAge(23); // p1 now "detached-dirty"
        try
        {
            tx.begin();
            pm.makePersistent(p1); // Attaches the change, p1 "persistent"
            tx.commit();
        }
        finally
        {
            if (tx.isActive()) { tx.rollback(); }
        }

        // Query for the Person objects with surname "Smith" and update the age
        try
        {
            tx.begin();
            Query q = pm.newQuery(
                    "SELECT FROM org.jpox.test.Person WHERE lastName == 'Smith'");
            List results = (List)q.execute();
            Person p = (Person)results.get(0); // p now "persistent"

            p.setAge(24); // Changes transparently persisted
            tx.commit();
        }
        finally
        {
            if (tx.isActive()) { tx.rollback(); }
        }

        // Perform a DB4O Native query for people older than 32
        try
        {
            tx.begin();
            Query q = pm.newQuery("Native", new Predicate()
            {
                public boolean match(Person p)
                {
                    return p.getAge() >= 32;
                }
            });

            List results = (List)q.execute();
            tx.commit();
        }
        finally
        {
            if (tx.isActive()) { tx.rollback(); }
        }

        pm.close();
    }
}
