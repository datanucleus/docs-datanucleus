package org.jpox.test;

import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Version;
import javax.jdo.annotations.VersionStrategy;
import javax.jdo.annotations.Index;

@PersistenceCapable(detachable="true")
@Version(strategy=VersionStrategy.VERSION_NUMBER)
public class Person
{
    String firstName;
    String lastName;

    @Index
    int age;

    public Person(String first, String last)
    {
        this.firstName = first;
        this.lastName = last;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public int getAge()
    {
        return age;
    }

    public void setAge(int age)
    {
        this.age = age;
    }
}
