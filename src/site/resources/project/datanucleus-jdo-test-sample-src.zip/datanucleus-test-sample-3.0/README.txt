user.testcase
=============
This project forms the basis of a DataNucleus Testcase (as defined in the docs).

The user provides the basic classes, datanucleus.properties, and Main.java
and we can then run it using the provided Maven2 project files.

To execute the testcase using Maven2 :
mvn clean compile exec:java

