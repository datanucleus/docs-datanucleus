package org.datanucleus.test;

import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Transaction;

import org.datanucleus.util.NucleusLogger;

/**
 * Sample Main.java for a DataNucleus testcase.
 * Make use of NucleusLogger to demonstrate issues.
 */
public class Main
{
    static public void main(String[] args)
    {
        // Create PMF from "datanucleus.properties" file
        PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");

        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx = pm.currentTransaction();
        try
        {
            tx.begin();

            // [PERSIST SOME OBJECTS]
 
            tx.commit();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            NucleusLogger.GENERAL.info(">> Exception thrown persisting objects", e);
            return;
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }

        pm = pmf.getPersistenceManager();
        tx = pm.currentTransaction();
        try
        {
            tx.begin();

            // [PERFORM SOME OPERATION ON THE OBJECTS?]

            tx.commit();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            NucleusLogger.GENERAL.info(">> Exception thrown retrieving objects", e);
            return;
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
    }
}